# Radar B2B Consultants AO IT — Pack premier euro

Statut : interne, non publié, sans paiement, sans tracking.

## Objectif

Préparer le chemin le plus court vers un premier euro symbolique sans action externe risquée : un pack vendable/testable à 1 € seulement si Geoffroy valide lui-même le canal de paiement et la publication.

## Contenu

- 15 signaux consultants AO qualifiés en source hebdo.
- `sample_consultant_ao_signals.csv` : 8 signaux démo.
- `index.html` : page locale d'offre test.
- `onepager_consultants_ao.html` : one-page beta existante copiée.

## Prix test

[ESTIMATION INCERTAINE] 1 € symbolique pour tester l'achat, puis hypothèse 19–49 €/mois si intérêt réel. Aucun revenu garanti.

## Garde-fous

- Pas de publication sans validation Geoffroy.
- Pas de compte externe créé par Hermes.
- Pas de RIB/IBAN/KYC/payout manipulé par Hermes.
- Pas d'outreach massif, pas de spam.
- Données publiques BOAMP uniquement dans cet échantillon.
