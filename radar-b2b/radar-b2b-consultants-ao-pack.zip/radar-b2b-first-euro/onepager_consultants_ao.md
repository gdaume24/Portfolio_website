# One-page beta — Radar B2B Consultants AO IT

> Interne/non publié. Page conçue pour rendre la démo immédiatement compréhensible avant toute exposition externe.

## Promesse en 20 secondes

Chaque semaine, le radar transforme les avis BOAMP IT/IA en une shortlist priorisée de comptes/opportunités pour consultants AO : 15 signaux qualifiés cette semaine, couvrant surtout AO exploitation / infogérance, AO data / IA / BI, AO cyber / conformité. La valeur vendue n'est pas l'accès au BOAMP, mais le tri, la qualité, la deadline, le CSV et l'angle de brief client immédiatement réutilisable.

## Ce que reçoit un beta-testeur

- Un brief hebdo top opportunités AO IT/IA, filtré par gate qualité.
- Un CSV exploitable avec score, segment AO, urgence, acheteur, deadline, URL officielle et angle consultant.
- Une shortlist qui évite de lire des dizaines d'avis bruts pour trouver les bons dossiers.
- Des scores qui servent de priorités de relecture, pas de promesses de gain de marché.

## Preuve de semaine type

- Shortlist hebdo disponible : **15** signaux consultants AO qualifiés.
- Aperçu one-page volontairement limité à **8** signaux pour rester lisible.
- Source : `weekly_consultant_ao_pack/shortlist_consultant_ao.csv`.
- Hypothèse prix à tester après feedback : [ESTIMATION INCERTAINE] 49–99 €/mois pour un solo consultant, plus pour cabinet.

## Aperçu — 8 signaux lisibles

| # | Score | Segment | Acheteur | Objet | Deadline | Angle de brief |
|---:|---:|---|---|---|---|---|
| 1 | 9 | AO exploitation / infogérance | CENTRE POMPIDOU | Prestations de services d'infogérance du système d'information du Centre Pompidou | 2026-07-16 | Brief client AO exploitation / infogérance pour CENTRE POMPIDOU : vérifier SLA, réversibilité, continuité de service et reprise d'existant. |
| 2 | 9 | AO exploitation / infogérance | GIE ORAS | Prestation d'infogérance du système d'information | 2026-07-31 | Brief client AO exploitation / infogérance pour GIE ORAS : vérifier SLA, réversibilité, continuité de service et reprise d'existant. |
| 3 | 9 | AO exploitation / infogérance | Communauté de Communes Inter Caux Vexin | Marché de modernisation, d'infogérance et de sécurisation du système d'information de la Communauté de Communes Inter Caux Vexin | 2026-08-31 | Brief client AO exploitation / infogérance pour Communauté de Communes Inter Caux Vexin : vérifier SLA, réversibilité, continuité de service et reprise d'existant. |
| 4 | 8 | AO cyber / conformité | Gip Grades Corse e-santé | Marché public de prestations de services en cybersécurité des systèmes d'information | 2026-07-27 | Brief client AO cyber / conformité pour Gip Grades Corse e-santé : vérifier périmètre SSI, exigences réglementaires, preuves et niveau de risque. |
| 5 | 8 | AO data / IA / BI | Ville de Sevran | Mise en oeuvre d'une solution logicielle de gestion du Centre Municipal de Santé incluant hébergement, maintenance et reprise de données | 2026-07-27 | Brief client AO data / IA / BI pour Ville de Sevran : vérifier cas d'usage, qualité des données, critères de succès et lotissement. |
| 6 | 8 | AO data / IA / BI | Grenoble Alpes Metropole | Fourniture et maintenance de sondes de télérelève de remplissage et logiciel d'exploitation des données collectées pour conteneurs d'apport volontaire à déchets ménagers | 2026-08-19 | Brief client AO data / IA / BI pour Grenoble Alpes Metropole : vérifier cas d'usage, qualité des données, critères de succès et lotissement. |
| 7 | 8 | AO data / IA / BI | Région Grand Est | Formation sur les usages et application de l'intelligence artificielle (IA) | 2026-08-20 | Brief client AO data / IA / BI pour Région Grand Est : vérifier cas d'usage, qualité des données, critères de succès et lotissement. |
| 8 | 8 | AO data / IA / BI | CNFPT - Direction de l'achat public | FORMATION - Architecture, développement et administration des SI - Intelligence Artificielle (IA) - A7A | 2026-09-04 | Brief client AO data / IA / BI pour CNFPT - Direction de l'achat public : vérifier cas d'usage, qualité des données, critères de succès et lotissement. |

## Couverture par segment

- AO exploitation / infogérance : 7
- AO data / IA / BI : 6
- AO cyber / conformité : 1
- AO logiciel métier : 1

## Question beta à poser plus tard

Est-ce que cette shortlist + CSV vous ferait gagner assez de temps de qualification BOAMP pour l'ouvrir chaque semaine ?

## Checklist qualité avant partage externe

- Aucun warning bloquant détecté dans la shortlist one-page.
- Relire manuellement les 8 signaux affichés avant tout partage public ou beta.
- Retirer tout signal sans deadline ou dont l'URL officielle BOAMP ne confirme pas un AO ouvert.
- Garder la page en noindex/no-follow tant que Geoffroy n'a pas validé la publication/partage.

## Garde-fous

- Asset interne/offline uniquement : aucune publication, aucun outreach, aucun formulaire, aucun tracking.
- Aucun compte externe, aucune dépense, aucun paiement, aucun RIB/IBAN, aucun secret et aucune donnée privée.
- Toute exposition externe reste soumise à [[Revenus/Validation queue]].

Fichiers générés : `consultant_ao_onepager/index.md`, `consultant_ao_onepager/index.html`, `consultant_ao_onepager/checklist_qualite.md`.
